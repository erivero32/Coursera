Mascotas, Recycler View y Action View

Para evaluar esta actividad deberás entregar:

1.	Pantallazos de la aplicación
2.	Enlace al proyecto GitHub

Review criteriamenos 

En esta actividad tus compañeros evaluarán:

1.	Que corra el proyecto
2.	DataSet
3.	Adapter
4.	ViewHolder
5.	Clase para dar forma a los items del RecyclerView
6.	Resultado final del RecyclerView
7.	Action View de estella
8.	Acciones del Action View
9.	RecyclerView con 5 Items
10.	Botón para subir
